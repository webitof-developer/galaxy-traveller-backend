const mongoose = require("mongoose");

const CreatorHomeSchema = new mongoose.Schema(
  {
    heroImage: { type: String }, // URL/path to hero image
    happyCustomer: { type: Number }, // URL/path to happy customer image

    // Relations
    creators: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    tours: [{ type: mongoose.Schema.Types.ObjectId, ref: "Tour" }],
    blogs: [{ type: mongoose.Schema.Types.ObjectId, ref: "Blog" }],

    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "draft",
      index: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      index: true,
    },

    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  }
);

// Flatten extras + normalize id
function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

// Indexes
CreatorHomeSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model("CreatorHome", CreatorHomeSchema);
