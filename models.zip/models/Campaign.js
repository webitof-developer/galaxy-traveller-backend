// models/Campaign.js
const mongoose = require("mongoose");
const {
  HeroSchema,
  PlanSchema,
  MomentSchema,
  TestimonialSchema,
} = require("./Shared");

// tiny slugify (no dep)
function slugify(str = "") {
  return String(str)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

// transform: flatten extras + normalize id
function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

const CampaignSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, maxlength: 200, index: true },
    slug: {
      type: String,
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^[a-z0-9-]+$/,
        "Slug can only contain lowercase letters, numbers, and hyphens",
      ],
      sparse: true,
      index: true,
    },

    // Require non-empty arrays
    hero: {
      type: [HeroSchema],
      validate: {
        validator: (v) => Array.isArray(v) && v.length > 0,
        message: "hero must have at least 1 item",
      },
      required: true,
    },
    plans: {
      type: [PlanSchema],
      validate: {
        validator: (v) => Array.isArray(v) && v.length > 0,
        message: "plans must have at least 1 item",
      },
      required: true,
    },
    moments: {
      type: [MomentSchema],
      validate: {
        validator: (v) => Array.isArray(v) && v.length > 0,
        message: "moments must have at least 1 item",
      },
      required: true,
    },
    destinations: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Destination",
        default: undefined,
      },
    ],
    testimonials: {
      type: [TestimonialSchema],
    },

    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      index: true,
    },

    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "draft",
      index: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  }
);

// Helpful indexes
CampaignSchema.index({ status: 1, createdAt: -1 });
CampaignSchema.index({ slug: 1 }, { unique: true, sparse: true });
CampaignSchema.index({ title: "text" });

// Auto-generate & normalize slug, ensure uniqueness
CampaignSchema.pre("validate", async function () {
  if (this.slug) this.slug = slugify(this.slug);
  if (!this.slug && this.title) this.slug = slugify(this.title);

  if (this.slug) {
    const base = this.slug;
    let candidate = base;
    let i = 1;
    while (
      await this.constructor.exists({
        slug: candidate,
        _id: { $ne: this._id },
      })
    ) {
      i += 1;
      candidate = `${base}-${i}`;
    }
    this.slug = candidate;
  }
});

module.exports = mongoose.model("Campaign", CampaignSchema);
