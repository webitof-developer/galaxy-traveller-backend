const mongoose = require("mongoose");

const ContactSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, minlength: 2, maxlength: 200 },
    email: {
      type: String,
      minlength: 3,
      maxlength: 200,
      match: /^\S+@\S+\.\S+$/,
    },
    contact: { type: String, required: true, min: 1, max: 9999999999999 },
    requirement: { type: String, required: true, minlength: 1, maxlength: 999 },
    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "draft",
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      index: true,
    },
    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  }
);

// Flatten extras + normalize id in output
function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

ContactSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model("Contact", ContactSchema);
