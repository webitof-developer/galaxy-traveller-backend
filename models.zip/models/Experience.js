// models/Experience.js (fixed)
const mongoose = require("mongoose");
const { HighlightSchema } = require("./Shared");
const slugify = require("slugify");

function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

const imgUrlRx = /^https?:\/\/.+\.(jpg|jpeg|png|webp|avif)(\?.*)?$/i;

const ExperienceSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, minlength: 4, maxlength: 34 },
    heroImg: {
      type: String,
      required: true,
    },
    highlight: { type: HighlightSchema, required: true, default: {} },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^[a-z0-9-]+$/,
        "Slug can only contain lowercase letters, numbers, and hyphens",
      ],
      index: true,
    },
    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "draft",
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      index: true,
    },

    // Relations
    destinations: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Destination",
        default: undefined,
      },
    ],
    spotlights: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Spotlight",
        default: undefined,
      },
    ],
    tours: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Tour", default: undefined },
    ],
    blogs: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Blog", default: undefined },
    ],
    tagMonths: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Month",
        default: undefined,
      },
    ],

    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  }
);

// --- Reverse virtuals ---
ExperienceSchema.virtual("destinationsReverse", {
  ref: "Destination",
  localField: "_id",
  foreignField: "experiences",
});

ExperienceSchema.virtual("toursReverse", {
  ref: "Tour",
  localField: "_id",
  foreignField: "experiences",
});

ExperienceSchema.virtual("blogsReverse", {
  ref: "Blog",
  localField: "_id",
  foreignField: "experiences",
});

ExperienceSchema.virtual("spotlightsReverse", {
  ref: "Spotlight",
  localField: "_id",
  foreignField: "experiences",
});

ExperienceSchema.virtual("tagMonthsReverse", {
  ref: "Month",
  localField: "_id",
  foreignField: "tagExperiences",
});

ExperienceSchema.pre("validate", function (next) {
  if (this.title && !this.slug) {
    this.slug = slugify(this.title, { lower: true, strict: true });
  }
  next();
});

// helpful indexes
ExperienceSchema.index({ status: 1, createdAt: -1 });
ExperienceSchema.index({ title: "text", slug: "text" });

module.exports = mongoose.model("Experience", ExperienceSchema);
