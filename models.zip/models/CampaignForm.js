// models/CampaignForm.js
const mongoose = require('mongoose');

// transform: flatten extras, normalize id, hide internals
function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // liberal email check
const phoneRx = /^[0-9+\-\s()]{6,20}$/; // simple phone-ish validation

const CampaignFormSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, maxlength: 200, trim: true },
    email: {
      type: String,
      required: true,
      maxlength: 200,
      trim: true,
      lowercase: true,
      validate: { validator: (v) => emailRx.test(v), message: 'Invalid email' },
      index: true,
    },
    contact: {
      type: String,
      required: true,
      maxlength: 20,
      minlength: 6,
      trim: true,
      validate: {
        validator: (v) => phoneRx.test(v),
        message: (props) => `${props.value} is not a valid contact number`,
      },
      index: true,
    },
    travelDate: { type: String, default: null, trim: true }, // keep as provided (string)
    destinations: { type: String, maxlength: 300, default: null, trim: true },
    needsHelp: { type: String, maxlength: 200, default: null, trim: true },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      index: true,
    },

    status: {
      type: String,
      enum: ['draft', 'published', 'rejected'],
      default: 'draft',
      index: true,
    },

    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  },
);

// Indexes for common access patterns & search
CampaignFormSchema.index({ status: 1, createdAt: -1 });
CampaignFormSchema.index({
  name: 'text',
  email: 'text',
  destinations: 'text',
  needsHelp: 'text',
});

module.exports = mongoose.model('CampaignForm', CampaignFormSchema);
