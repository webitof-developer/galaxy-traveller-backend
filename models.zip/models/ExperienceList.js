const mongoose = require("mongoose");
const { ExperienceGroupSchema } = require("./Shared");

const ListExperienceSchema = new mongoose.Schema(
  {
    group: {
      type: [ExperienceGroupSchema],
      default: [],
    },
    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "published",
      index: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: flattenExtras },
    toObject: { virtuals: true, transform: flattenExtras },
  }
);

// Flatten extras into top-level fields
function flattenExtras(doc, ret) {
  if (ret.extras) {
    for (const [key, value] of Object.entries(ret.extras)) {
      // Only overwrite if field doesn't exist at top level
      if (ret[key] === undefined) {
        ret[key] = value;
      }
    }
    delete ret.extras; // optional: remove extras wrapper
  }
  return ret;
}

module.exports = mongoose.model("ListExperience", ListExperienceSchema);
