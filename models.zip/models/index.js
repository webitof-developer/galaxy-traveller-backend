const Blog = require("./Blog");
const Campaign = require("./Campaign");
const CampaignForm = require("./CampaignForm");
const Category = require("./Category");
const Contact = require("./Contact");
const CreatorHome = require("./CreatorHome");
const Destination = require("./Destination");
const DestinationList = require("./DestinationList");
const Enquiry = require("./Enquire");
const Experience = require("./Experience");
const ExperienceList = require("./ExperienceList");
const Features = require("./Features");
const Global = require("./Global");
const HeroSlide = require("./HeroSlide");
const Lead = require("./Lead");
const Month = require("./Month");
const Review = require("./Review");
const Spotlight = require("./Spotlight");
const Testimonial = require("./Testimonial");
const Tour = require("./Tour");
const TourList = require("./TourList");

// export all models in consistent structure
const models = {
  blog: {
    model: Blog,
    meta: {
      name: "Blog",
      key: "blog",
      collectionType: "collection",
      ui: { icon: "IconBook" },
      route: "/api/blog",
    },
  },
  campaigns: {
    model: Campaign,
    meta: {
      name: "Campaign",
      key: "campaigns",
      collectionType: "collection",
      ui: { icon: "IconMegaphone" },
      route: "/api/campaigns",
    },
  },
  campaignforms: {
    model: CampaignForm,
    meta: {
      name: "Campaign Form",
      key: "campaignforms",
      collectionType: "collection",
      ui: { icon: "IconForm" },
      route: "/api/campaignforms",
    },
  },
  categories: {
    model: Category,
    meta: {
      name: "Category",
      key: "categories",
      collectionType: "collection",
      ui: { icon: "IconFolder" },
      route: "/api/categories",
    },
  },
  contact: {
    model: Contact,
    meta: {
      name: "Contact",
      key: "contact",
      collectionType: "collection",
      ui: { icon: "IconPhone" },
      route: "/api/contact",
    },
  },
  destinations: {
    model: Destination,
    meta: {
      name: "Destination",
      key: "destinations",
      collectionType: "collection",
      ui: { icon: "IconMap" },
      route: "/api/destinations",
    },
  },
  enquiries: {
    model: Enquiry,
    meta: {
      name: "Enquiries",
      key: "enquiries",
      collectionType: "collection",
      ui: { icon: "IconCalendarQuestion" },
      route: "/api/enquiry",
    },
  },
  experiences: {
    model: Experience,
    meta: {
      name: "Experience",
      key: "experiences",
      collectionType: "collection",
      ui: { icon: "IconCompass" },
      route: "/api/experiences",
    },
  },
  lead: {
    model: Lead,
    meta: {
      name: "Lead",
      key: "lead",
      collectionType: "collection",
      ui: { icon: "IconHeadset" },
      route: "/api/lead",
    },
  },
  months: {
    model: Month,
    meta: {
      name: "Month",
      key: "months",
      collectionType: "collection",
      ui: { icon: "IconCalendar" },
      route: "/api/months",
    },
  },
  spotlight: {
    model: Spotlight,
    meta: {
      name: "Spotlight",
      key: "spotlight",
      collectionType: "collection",
      ui: { icon: "IconFocus" },
      route: "/api/spotlight",
    },
  },
  testimonial: {
    model: Testimonial,
    meta: {
      name: "Testimonial",
      key: "testimonial",
      collectionType: "collection",
      ui: { icon: "IconMessageDots" },
      route: "/api/testimonial",
    },
  },
  tour: {
    model: Tour,
    meta: {
      name: "Tour",
      key: "tour",
      collectionType: "collection",
      ui: { icon: "IconRoute" },
      route: "/api/tour",
    },
  },

  // --- Site Management (Admin only — dashboard) ---
  site_destinationslist: {
    model: DestinationList,
    meta: {
      name: "Destination List",
      key: "site_destinationslist",
      collectionType: "single",
      ui: { icon: "IconList" },
      route: "/api/site_destinationsList",
    },
  },
  site_global: {
    model: Global,
    meta: {
      name: "Global",
      key: "site_global",
      collectionType: "single",
      ui: { icon: "IconList" },
      route: "/api/site_global",
    },
  },
  site_features: {
    model: Features,
    meta: {
      name: "Features",
      key: "site_features",
      collectionType: "single",
      ui: { icon: "IconSparkles" },
      route: "/api/site_features",
    },
  },
  site_creator: {
    model: CreatorHome,
    meta: {
      name: "Creator Home",
      key: "site_creator",
      collectionType: "single",
      ui: { icon: "IconPackages" },
      route: "/api/site_creator",
    },
  },
  site_experienceslist: {
    model: ExperienceList,
    meta: {
      name: "Experience List",
      key: "site_experienceslist",
      collectionType: "single",
      ui: { icon: "IconListDetails" },
      route: "/api/site_experienceslist",
    },
  },
  reviews: {
    model: Review,
    meta: {
      name: "Reviews",
      key: "review",
      collectionType: "single",
      ui: { icon: "IconMessageDots" },
      route: "/api/review",
    },
  },
  site_heroslides: {
    model: HeroSlide,
    meta: {
      name: "Hero Slides",
      key: "site_heroslides",
      collectionType: "single",
      ui: { icon: "IconSlideshow" },
      route: "/api/site_heroslides",
    },
  },
  site_tourlist: {
    model: TourList,
    meta: {
      name: "Tour List",
      key: "site_tourlist",
      collectionType: "single",
      ui: { icon: "IconChecklist" },
      route: "/api/site_tourlist",
    },
  },

  // --- Core auth & roles ---
  // users: {
  //   model: User,
  //   meta: {
  //     name: 'User',
  //     key: 'users',
  //     collectionType: 'collection',
  //     ui: { icon: 'IconUser' },
  //     route: '/api/users',
  //   },
  // },
  // role: {
  //   model: Role,
  //   meta: {
  //     name: 'Role',
  //     key: 'roles',
  //     collectionType: 'collection',
  //     ui: { icon: 'IconShield' },
  //     route: '/api/roles',
  //   },
  // },
};

module.exports = {
  models,
};
