// models/ListTour.js
const mongoose = require('mongoose');
const { TourGroupSchema } = require('./Shared');

function transformOut(doc, ret) {
  // flatten extras if ever present
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

const ListTourSchema = new mongoose.Schema(
  {
    group: {
      type: [TourGroupSchema], // we operate only on group[0]
      required: true,
      default: [],
    },
    status: {
      type: String,
      enum: ['draft', 'published', 'rejected'],
      default: 'published',
      index: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  },
);

ListTourSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('ListTour', ListTourSchema);
