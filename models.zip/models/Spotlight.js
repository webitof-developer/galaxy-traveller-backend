// models/Spotlight.js (fixed)
const mongoose = require("mongoose");

// Flatten extras + normalize id in output
function transformOut(doc, ret) {
  if (ret.extras) {
    for (const [k, v] of Object.entries(ret.extras)) {
      if (ret[k] === undefined) ret[k] = v;
    }
    delete ret.extras;
  }
  ret.id = ret._id;
  delete ret._id;
  delete ret.__v;
  return ret;
}

const imgUrlRx = /^https?:\/\/.+\.(jpg|jpeg|png|webp|avif)(\?.*)?$/i;

const SpotlightSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      minlength: 4, // <- fix key
      maxlength: 50, // <- fix key
    },
    displayImg: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
      minlength: 10, // <- fix key
      maxlength: 500, // <- fix key
    },

    // Relations
    tour: { type: mongoose.Schema.Types.ObjectId, ref: "Tour" },
    destination: { type: mongoose.Schema.Types.ObjectId, ref: "Destination" },
    experiences: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Experience",
        default: undefined,
      },
    ],

    status: {
      type: String,
      enum: ["draft", "published", "rejected"],
      default: "draft",
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      index: true,
    },

    extras: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true, transform: transformOut },
    toObject: { virtuals: true, transform: transformOut },
  }
);

// Helpful indexes (no new fields)
SpotlightSchema.index({ status: 1, createdAt: -1 });
SpotlightSchema.index({ title: "text", description: "text" });

// --- Reverse virtuals ---
SpotlightSchema.virtual("toursReverse", {
  ref: "Tour",
  localField: "_id",
  foreignField: "spotlights",
});

SpotlightSchema.virtual("destinationsReverse", {
  ref: "Destination",
  localField: "_id",
  foreignField: "spotlights",
});

SpotlightSchema.virtual("experiencesReverse", {
  ref: "Experience",
  localField: "_id",
  foreignField: "spotlights",
});

module.exports = mongoose.model("Spotlight", SpotlightSchema);
