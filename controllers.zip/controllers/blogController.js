// controllers/blog.controller.js
const mongoose = require("mongoose");
const Blog = require("../models/Blog");
const User = require("../models/User");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const { buildFolderPath } = require("../utils/pathbuilderandpublicurl");
const { deleteImageFromGCS, uploadImage } = require("../utils/uploadHelper");
const { notifyUser } = require("../utils/notifyUser");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

function updateSubSchemaFields(updateData, subSchemaKey, schemaFields) {
  if (updateData[subSchemaKey]) {
    schemaFields.forEach((field) => {
      if (updateData[subSchemaKey][field] !== undefined) {
        updateData[`${subSchemaKey}.${field}`] =
          updateData[subSchemaKey][field];
      }
    });
    delete updateData[subSchemaKey]; // Remove the full sub-schema to avoid conflict
  }
}

// ---------- Helpers ----------

const buildCommonFilters = (req) => {
  const f = {};
  // explicit status filter (listAll permits any; listPublished forces 'published' elsewhere)
  if (req.query.status) f.status = req.query.status;

  // createdBy
  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  // categories / tagMonths (accept single or CSV)
  if (req.query.categories) {
    const arr = String(req.query.categories)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map(coerceId)
      .filter(Boolean);
    if (arr.length) f.categories = { $in: arr };
  }

  if (req.query.tagMonths) {
    const arr = String(req.query.tagMonths)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map(coerceId)
      .filter(Boolean);
    if (arr.length) f.tagMonths = { $in: arr };
  }

  // date range
  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;
  if (from || to) {
    f.createdAt = {};
    if (from && !isNaN(from)) f.createdAt.$gte = from;
    if (to && !isNaN(to)) f.createdAt.$lte = to;
    if (!Object.keys(f.createdAt).length) delete f.createdAt;
  }

  return f;
};

function clean(obj) {
  Object.keys(obj).forEach((k) => {
    const v = obj[k];
    if (v === undefined || v === null || v === "") delete obj[k];
    if (typeof v === "object" && !Array.isArray(v)) clean(v);
  });
  return obj;
}

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit = 15, skip } = parsePagination(req);
  const filters = buildCommonFilters(req);
  const search = buildSearch(req.query.q);

  const where = { status: "published", ...(filters || {}) };

  let createdBy = null;

  if (req.query.id) {
    const val = req.query.id;

    if (mongoose.Types.ObjectId.isValid(val)) {
      createdBy = await User.findById(val);
    } else {
      createdBy = await User.findOne({ slug: val });
    }

    if (createdBy) {
      where.createdBy = createdBy._id;
    }
  }

  console.log("createdBy", createdBy, where);

  if (search) Object.assign(where, search);

  const sort = { updatedAt: -1 };

  const [items, total] = await Promise.all([
    Blog.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Blog.countDocuments(where),
  ]);

  console.log(items);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = req.params.idOrSlug;
  const where = isObjectId(p) ? { _id: p } : { slug: String(p).toLowerCase() };

  // Only published for public
  const doc = await Blog.findOne({ ...where, status: "published" })
    .populate("categories")
    .populate("tagMonths")
    .populate("blogs")
    .populate("blogsReverse")
    .populate("tours")
    .populate("toursReverse")
    .populate("destinations")
    .populate("destinationsReverse")
    .populate("experiences")
    .populate("experiencesReverse")
    .populate("createdBy")

    .lean();
  if (!doc) return notFound(res, "Blog not found");
  return ok(res, doc);
});

// ---------- Moderation (protected by ensurePermission) ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);

  const search = buildSearch(req.query.q, [
    "title",
    "slug",
    "description",
    "body",
    "author",
  ]);

  const filters = clean(buildCommonFilters(req));

  const where = { ...(filters || {}) };

  const role = (req.user?.roleName || req.user?.role || "").toLowerCase();
  if (role === "creator") {
    where.createdBy = req.user._id;
  }

  if (search) Object.assign(where, search);

  console.log(where, search, req.query.q);

  const [items, total] = await Promise.all([
    Blog.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Blog.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Blog.findById(id).lean();
  if (!doc) return notFound(res, "Blog not found");
  return ok(res, doc);
});

// ---------- My Blogs ----------
exports.listMyBlogs = asyncHandler(async (req, res) => {
  console.log(req.user);
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { createdBy: req.user._id, ...buildFilters(req) };

  const search = buildSearch(req.query.q, ["title", "description", "author"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Blog.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Blog.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// ---------- CRUD ----------
exports.create = asyncHandler(async (req, res) => {
  // Step 1: Create the blog first (so we have the recordId)
  const createdBy = req.body.createdBy || req.user._id;
  const payload = {
    ...req.body,
    createdBy: createdBy, // ensure ownership
  };

  // Create the blog document (without images initially)
  const doc = await Blog.create(payload);

  // Step 2: Handle images (if provided)
  if (req.files && req.files.length > 0) {
    const imageUrls = []; // Will hold the GCS URLs of the uploaded images

    // Loop over each image file and upload it to GCS
    for (const file of req.files) {
      const folderPath = buildFolderPath({
        modelKey: "blog",
        userId: req.user._id,
        recordId: doc._id, // Now use the created blog's _id
      });

      const imageUrl = await uploadImage({
        folderPath,
        file,
        modelKey: "blog",
        userId: req.user._id,
        recordId: doc._id, // Use the blog's recordId to store the image
      });

      imageUrls.push(imageUrl);
    }

    // Step 3: Update the blog with image URLs
    doc.images = imageUrls; // Add image URLs to the blog document
    await doc.save(); // Save the blog with updated images
  }

  // Return the created blog with images
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const updates = { ...req.body };

  // Update highlight sub-schema if exists
  updateSubSchemaFields(updates, "seo", [
    "metaDescription",
    "metaTitle",
    "shareImage",
  ]);

  const existingBlog = await Blog.findById(id).select("status createdBy");
  if (!existingBlog) return notFound(res, "Blog not found");

  // (Optionally) prevent changing createdBy via update
  // if ("createdBy" in updates) delete updates.createdBy;

  // Handle images (if provided)
  if (req.files && req.files.length > 0) {
    // Assuming `req.files` contains images sent in a multi-part form
    const imageUrls = []; // Will hold the GCS URLs of the uploaded images

    // Loop over each image file and upload it to GCS
    for (const file of req.files) {
      const folderPath = buildFolderPath({
        modelKey: "blog",
        userId: req.user._id,
        recordId: id, // Use the existing blog ID for folder path
      });

      const imageUrl = await uploadImage({
        folderPath,
        file,
        modelKey: "blog",
        userId: req.user._id,
        recordId: id, // Using the blog's ID to store the image in the correct path
      });

      imageUrls.push(imageUrl);
    }

    // If new images were uploaded, add them to the update payload
    updates.images = [...(updates.images || []), ...imageUrls];
  }

  // Handle old image removal (if specified in the request)
  if (req.body.removeImages && Array.isArray(req.body.removeImages)) {
    const imagesToRemove = req.body.removeImages;

    // Delete images from GCS (use their URLs or object names)
    for (const image of imagesToRemove) {
      await deleteImageFromGCS(image); // This helper function will remove images from GCS
    }

    // Remove the deleted images from the blog's array of images
    updates.images = (updates.images || []).filter(
      (img) => !imagesToRemove.includes(img)
    );
  }

  const doc = await Blog.findByIdAndUpdate(
    id,
    { $set: updates },
    { new: true, runValidators: true }
  ).lean();

  if (!doc) return notFound(res, "Blog not found");

  // Notify user if status changed
  if (updates.status && updates.status !== existingBlog.status) {
    // Fetch the user email
    const user = await User.findById(existingBlog.createdBy).select("email");
    if (user && user.email) {
      await notifyUser({
        type: "content",
        content: {
          title: doc.title,
          status: doc.status,
          rejectionReason: doc.rejectionReason,
          ownerEmail: user.email,
        },
        url: `${process.env.PUBLIC_URL}/blogs/${doc._id}`,
      });
    }
  }

  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await Blog.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();

  if (!doc) return notFound(res, "Blog not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Blog.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Blog not found");
  return ok(res, { id });
});

// ---------- Duplicate Blog ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Blog.findById(id).lean();
  if (!original) return notFound(res, "Blog not found");

  // 🧠 Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined,
    title: original.title ? `${original.title} (Copy)` : "Untitled (Copy)",
    status: "draft",
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  // ✅ Ensure unique slug
  if (duplicatedData.slug)
    duplicatedData.slug = `${duplicatedData.slug}-copy-${Date.now()}`;

  // ✅ Ensure unique SEO fields
  if (duplicatedData.seo?.metaTitle)
    duplicatedData.seo.metaTitle = `${duplicatedData.seo.metaTitle} (Copy)`;

  if (duplicatedData.seo?.metaDescription)
    duplicatedData.seo.metaDescription = `${duplicatedData.seo.metaDescription} (Copy)`;

  // Optional: clear timestamps or regenerate
  delete duplicatedData.createdAt;
  delete duplicatedData.updatedAt;

  const duplicate = await Blog.create(duplicatedData);

  return created(res, {
    message: "Blog duplicated successfully",
    duplicate,
  });
});
