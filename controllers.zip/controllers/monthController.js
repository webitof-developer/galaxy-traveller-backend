// controllers/month.controller.js
const Month = require("../models/Month");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;

  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  const tagBlogs = csvObjectIds(req.query.tagBlogs);
  if (tagBlogs) f.tagBlogs = { $in: tagBlogs };

  const tagDestinations = csvObjectIds(req.query.tagDestinations);
  if (tagDestinations) f.tagDestinations = { $in: tagDestinations };

  const tagExperiences = csvObjectIds(req.query.tagExperiences);
  if (tagExperiences) f.tagExperiences = { $in: tagExperiences };

  const tagTours = csvObjectIds(req.query.tagTours);
  if (tagTours) f.tagTours = { $in: tagTours };

  applyDateRange(f, req, "createdAt");
  return f;
};

function updateSubSchemaFields(updateData, subSchemaKey, schemaFields) {
  if (updateData[subSchemaKey]) {
    schemaFields.forEach((field) => {
      if (updateData[subSchemaKey][field] !== undefined) {
        updateData[`${subSchemaKey}.${field}`] =
          updateData[subSchemaKey][field];
      }
    });
    delete updateData[subSchemaKey]; // Remove the full sub-schema to avoid conflict
  }
}

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { status: "published", ...buildFilters(req) };
  const search = buildSearch(req.query.q, ["month", "monthTag"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Month.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Month.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// GET by id or monthTag (slug-like)
exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { month: p.toLowerCase() };
  const doc = await Month.findOne({ ...where, status: "published" })
    .populate("tagBlogs")
    .populate("tagBlogsReverse")
    .populate("tagDestinations")
    .populate("tagDestinationsReverse")
    .populate("tagTours")
    .populate("tagToursReverse")
    .populate("tagExperiences")
    .populate("tagExperiencesReverse")

    .lean();
  if (!doc) return notFound(res, "Month not found");
  return ok(res, doc);
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);
  const search = buildSearch(req.query.q, ["month", "monthTag"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Month.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Month.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Month.findById(id).lean();
  if (!doc) return notFound(res, "Month not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  const doc = await Month.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy;

  // Update highlight sub-schema if exists
  updateSubSchemaFields(updates, "highlight", ["title", "brief", "img"]);

  const doc = await Month.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();

  if (!doc) return notFound(res, "Month not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await Month.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "Month not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Month.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Month not found");
  return ok(res, { id });
});

// ---------- Duplicate Month ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Month.findById(id).lean();
  if (!original) return notFound(res, "Month not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined, // remove original ID
    month: original.month ? `${original.month} (Copy)` : "Untitled (Copy)",
    monthTag: `${original.monthTag || "month"}-copy-${Date.now()}`, // ensure uniqueness
    status: "draft", // default duplicate to draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await Month.create(duplicatedData);

  return created(res, {
    message: "Month duplicated successfully",
    duplicate,
  });
});
