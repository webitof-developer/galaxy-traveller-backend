const HeroSlide = require("../models/HeroSlide");
const Destination = require("../models/Destination");
const Experience = require("../models/Experience");
const Review = require("../models/Review");
const Blog = require("../models/Blog");
const Month = require("../models/Month");
const User = require("../models/User");
const Tour = require("../models/Tour");
const Feature = require("../models/Features");
const { ok, notFound, fail, asyncHandler } = require("../utils/respond");
const CreatorHome = require("../models/CreatorHome");

dotenv = require("dotenv");
dotenv.config();

exports.getHomeData = async (req, res) => {
  try {
    // Fetch data in parallel
    const [
      heroSlides,
      months,
      destinations,
      experiences,
      tours,
      features,
      reviews,
    ] = await Promise.all([
      HeroSlide.find({ status: "published" }).sort({ createdAt: -1 }).lean(),
      Month.find({ status: "published" }).sort({ createdAt: -1 }).lean(),
      Destination.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(6)
        .lean(),
      Experience.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(6)
        .lean(),
      Tour.find({ status: "published", createdByRole: "admin" })
        .sort({ createdAt: -1 })
        .limit(6)
        .lean(),

      Feature.find({ status: "published" })
        .sort({ createdAt: -1 })
        .populate("blogs destinations experiences traveller tours")
        .lean(),
      Review.find({ status: "published" }).sort({ createdAt: -1 }).lean(),
    ]);

    // Flatten the data
    const heroSlidesData = heroSlides[0]?.heroSlide || [];
    const reviewData = reviews[0]?.group || [];

    return ok(res, {
      hero: heroSlidesData,
      months,
      destinations,
      experiences,
      tours,
      features,
      reviews: reviewData,
    });
  } catch (err) {
    console.error("Error fetching home data:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch home data",
      error: err.message,
    });
  }
};

exports.searchHomeData = async (req, res) => {
  try {
    const query = req.params.query.trim().toLowerCase();
    const filter = (req.query.filter || "all").toLowerCase();

    let destinations = [],
      experiences = [],
      tours = [],
      blogs = [],
      creators = [],
      creatorBlogs = [],
      creatorTours = [];

    if (filter === "all" || filter === "destinations") {
      destinations = await Destination.find({
        title: { $regex: query, $options: "i" },
        status: "published",
      }).lean();
    }

    if (filter === "all" || filter === "experiences") {
      experiences = await Experience.find({
        title: { $regex: query, $options: "i" },
        status: "published",
      }).lean();
    }

    if (filter === "all" || filter === "tours") {
      tours = await Tour.find({
        title: { $regex: query, $options: "i" },
        status: "published",
        createdByRole: "admin",
      }).lean();
    }

    if (filter === "all" || filter === "blogs") {
      blogs = await Blog.find({
        title: { $regex: query, $options: "i" },
        status: "published",
        createdByRole: "admin",
      }).lean();
    }

    if (filter === "all" || filter === "creator") {
      creators = await User.find({
        name: { $regex: query, $options: "i" },
        status: "active",
        roleName: "creator",
      }).lean();
    }

    if (filter === "all" || filter === "creatorBlogs") {
      creatorBlogs = await Blog.find({
        createdByRole: "creator",
        title: { $regex: query, $options: "i" },
        status: "published",
      }).lean();
    }

    if (filter === "all" || filter === "creatorTours") {
      creatorTours = await Tour.find({
        createdByRole: "creator",
        title: { $regex: query, $options: "i" },
        status: "published",
      }).lean();
    }

    return ok(res, {
      destinations,
      experiences,
      tours,
      blogs,
      creators,
      creatorBlogs,
      creatorTours,
    });
  } catch (err) {
    console.error("Error searching home data:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to search home data",
      error: err.message,
    });
  }
};

exports.getCreatorHomeData = async (req, res) => {
  try {
    // Fetch the single CreatorHome document (status: published)
    const home = await CreatorHome.findOne({ status: "published" })
      .populate({
        path: "creators",
        select: "name profileImg roleName backgroundImg location",
        match: { status: "active" },
      })
      .populate({
        path: "tours",
        match: { status: "published" },
        options: { sort: { createdAt: -1, _id: -1 }, limit: 4 },
      })
      .populate({
        path: "blogs",
        match: { status: "published" },
        options: { sort: { createdAt: -1, _id: -1 }, limit: 3 },
      })
      .lean();

    // Fallback if no home document exists
    if (!home) {
      return res.status(201).json({
        success: false,
        message: "Creator home data not found",
      });
    }

    // Combine everything into one response
    return res.status(200).json({
      success: true,
      heroImage: home.heroImage,
      happyCustomer: home.happyCustomer,
      creators: home.creators || [],
      tours: home.tours || [],
      blogs: home.blogs || [],
      extras: home.extras || {},
      reviews: home.testimonials || [],
    });
  } catch (err) {
    console.error("Error fetching creator home data:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch creator home data",
    });
  }
};

exports.searchCreatorData = async (req, res) => {
  try {
    const query = req.params.query.trim().toLowerCase();
    const filter = (req.query.filter || "all").toLowerCase();

    let creators = [],
      blogs = [],
      tours = [];

    if (filter === "all" || filter === "creator") {
      creators = await User.find({
        roleName: "creator",
        status: "active",
        name: { $regex: query, $options: "i" },
      }).lean();
    }

    if (filter === "all" || filter === "blogs") {
      blogs = await Blog.find({
        status: "published",
        createdByRole: "creator",
        title: { $regex: query, $options: "i" },
      }).lean();
    }

    if (filter === "all" || filter === "tours") {
      tours = await Tour.find({
        status: "published",
        createdByRole: "creator",
        title: { $regex: query, $options: "i" },
      }).lean();
    }

    return ok(res, {
      creators,
      blogs,
      tours,
    });
  } catch (err) {
    console.error("Error searching creator data:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to search creator data",
      error: err.message,
    });
  }
};

exports.getMainData = async (req, res) => {
  try {
    const today = new Date();

    const [
      creators,
      blogs,
      upcomingTours,
      popularDestination,
      popularExperience,
      reviews,
    ] = await Promise.all([
      // 2 Creators (active)
      User.find({ status: "active", roleName: "creator" })
        .sort({ createdAt: -1 })
        .limit(8)
        .select("name profileImg location")
        .lean(),
      // 2 Blogs (with populated creator name)
      Blog.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(4)
        .select("title heroImg createdBy slug")
        .populate("createdBy", "name")
        .lean(),

      // 🚀 Upcoming tours (start date in future)
      Tour.find({
        status: "published",
        "dateRange.startDate": { $gte: today },
      })
        .sort({ "dateRange.startDate": 1 }) // soonest first
        .limit(6)
        .select("title heroImg place dateRange createdBy slug details")
        .populate("createdBy", "name")
        .lean(),
      Destination.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(6)
        .select("title description heroImg startingPrice slug createdBy")
        .populate("createdBy", "name")
        .lean(),
      Experience.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(6)
        .select("title description heroImg slug createdBy")
        .populate("createdBy", "name")
        .lean(),
      // ⭐ Reviews (published)
      Review.find({ status: "published" })
        .sort({ createdAt: -1 })
        .limit(6)
        .lean(),
    ]);

    // If reviews are grouped under a single doc (like ReviewSchema { group: [] })
    const reviewsData =
      Array.isArray(reviews) && reviews.length && reviews[0].group
        ? reviews[0].group
        : reviews;

    return ok(res, {
      creators,
      blogs,
      upcomingTours,
      popularDestination,
      popularExperience,
      reviews: reviewsData,
    });
  } catch (err) {
    console.error("Error fetching main data:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch main data",
      error: err.message,
    });
  }
};
