// controllers/experience.controller.js
const Experience = require("../models/Experience");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

// Build filters from query
const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;

  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  const destinations = csvObjectIds(req.query.destinations);
  if (destinations) f.destinations = { $in: destinations };

  const spotlights = csvObjectIds(req.query.spotlights);
  if (spotlights) f.spotlights = { $in: spotlights };

  const tours = csvObjectIds(req.query.tours);
  if (tours) f.tours = { $in: tours };

  const blogs = csvObjectIds(req.query.blogs);
  if (blogs) f.blogs = { $in: blogs };

  const tagMonths = csvObjectIds(req.query.tagMonths);
  if (tagMonths) f.tagMonths = { $in: tagMonths };

  applyDateRange(f, req, "createdAt");
  return f;
};

function updateSubSchemaFields(updateData, subSchemaKey, schemaFields) {
  if (updateData[subSchemaKey]) {
    schemaFields.forEach((field) => {
      if (updateData[subSchemaKey][field] !== undefined) {
        updateData[`${subSchemaKey}.${field}`] =
          updateData[subSchemaKey][field];
      }
    });
    delete updateData[subSchemaKey]; // Remove the full sub-schema to avoid conflict
  }
}

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { status: "published", ...buildFilters(req) };
  const search = buildSearch(req.query.q, ["title", "slug"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Experience.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Experience.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { slug: p.toLowerCase() };
  const doc = await Experience.findOne({
    ...where,
    status: "published",
  })
    .populate("destinations")
    .populate("destinationsReverse")
    .populate("spotlights")
    .populate("spotlightsReverse")
    .populate("tours")
    .populate("toursReverse")
    .populate("blogs")
    .populate("blogsReverse")
    .populate("tagMonths")
    .populate("tagMonthsReverse")
    .populate("createdBy")
    .lean();
  if (!doc) return notFound(res, "Experience not found");
  return ok(res, doc);
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);
  if ((req.user?.roleName || req.user?.role) == "creator") {
    where.createdBy = req.user._id;
  }
  const search = buildSearch(req.query.q, ["title", "slug"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Experience.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Experience.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Experience.findById(id).lean();
  if (!doc) return notFound(res, "Experience not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  const doc = await Experience.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  let updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy;

  // If 'highlight' is a sub-schema
  updateSubSchemaFields(updates, "highlight", ["title", "brief", "img"]);

  const doc = await Experience.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();

  if (!doc) return notFound(res, "Experience not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await Experience.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "Experience not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Experience.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Experience not found");
  return ok(res, { id });
});

// ---------- Duplicate Experience ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Experience.findById(id).lean();
  if (!original) return notFound(res, "Experience not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined, // remove original ID
    title: original.title ? `${original.title} (Copy)` : "Untitled (Copy)",
    slug: `${original.slug || "experience"}-copy-${Date.now()}`, // ensure uniqueness
    status: "draft", // duplicate starts as draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await Experience.create(duplicatedData);

  return created(res, {
    message: "Experience duplicated successfully",
    duplicate,
  });
});
