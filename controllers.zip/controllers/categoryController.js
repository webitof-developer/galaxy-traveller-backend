// controllers/category.controller.js
const mongoose = require("mongoose");
const Category = require("../models/Category");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");

const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;
  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }
  if (req.query.blogs) {
    const arr = String(req.query.blogs)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map(coerceId)
      .filter(Boolean);
    if (arr.length) f.blogs = { $in: arr };
  }
  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;
  if (from || to) {
    f.createdAt = {};
    if (from && !isNaN(from)) f.createdAt.$gte = from;
    if (to && !isNaN(to)) f.createdAt.$lte = to;
    if (!Object.keys(f.createdAt).length) delete f.createdAt;
  }
  return f;
};

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const where = { status: "published", ...buildFilters(req) };
  const search = buildSearch(req.query.q);

  if (search) Object.assign(where, search);

  // Fetch categories without pagination or population
  const categories = await Category.find(where).populate("blogs").lean();
  return ok(res, {
    items: categories,
  });
});

// Use id OR tag (slug-like) for public fetch
exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { tag: p.toLowerCase() };
  const doc = await Category.findOne({ ...where, status: "published" }).lean();
  if (!doc) return notFound(res, "Category not found");
  return ok(res, doc);
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);
  const search = buildSearch(req.query.q);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Category.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Category.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Category.findById(id).lean();
  if (!doc) return notFound(res, "Category not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  // tag normalization is handled by schema (trim/lowercase)
  const doc = await Category.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy; // do not allow owner change
  const doc = await Category.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();
  if (!doc) return notFound(res, "Category not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status))
    return fail(res, "Invalid status", 400);
  const doc = await Category.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "Category not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Category.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Category not found");
  return ok(res, { id });
});

// ---------- Duplicate Category ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Category.findById(id).lean();
  if (!original) return notFound(res, "Category not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined,
    name: original.name ? `${original.name} (Copy)` : "Untitled (Copy)",
    tag: `${original.tag || "category"}-copy-${Date.now()}`, // ensure unique tag
    status: "draft", // default new duplicate to draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await Category.create(duplicatedData);

  return created(res, {
    message: "Category duplicated successfully",
    duplicate,
  });
});
