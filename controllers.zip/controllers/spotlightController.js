// controllers/spotlight.controller.js
const Spotlight = require("../models/Spotlight");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;

  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  if (req.query.tour) {
    const id = coerceId(req.query.tour);
    if (id) f.tour = id;
  }

  if (req.query.destination) {
    const id = coerceId(req.query.destination);
    if (id) f.destination = id;
  }

  const experiences = csvObjectIds(req.query.experiences);
  if (experiences) f.experiences = { $in: experiences };

  applyDateRange(f, req, "createdAt");
  return f;
};

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { status: "published", ...buildFilters(req) };
  const search = buildSearch(req.query.q, ["title", "description"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Spotlight.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Spotlight.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// Public read: id OR title (case-insensitive exact match) since no slug field
exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p)
    ? { _id: p }
    : { title: new RegExp(`^${escapeRegex(p)}$`, "i") };

  const doc = await Spotlight.findOne({ ...where, status: "published" })
    .populate("tour")
    .populate("toursReverse")
    .populate("destination")
    .populate("destinationsReverse")
    .populate("experiences")
    .populate("experiencesReverse")
    .lean();
  if (!doc) return notFound(res, "Spotlight not found");
  return ok(res, doc);
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);

  if ((req.user?.roleName || req.user?.role) == "creator") {
    where.createdBy = req.user._id;
  }
  const search = buildSearch(req.query.q, ["title", "description"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Spotlight.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Spotlight.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Spotlight.findById(id).lean();
  if (!doc) return notFound(res, "Spotlight not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  const doc = await Spotlight.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy;

  const doc = await Spotlight.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();
  if (!doc) return notFound(res, "Spotlight not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await Spotlight.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "Spotlight not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Spotlight.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Spotlight not found");
  return ok(res, { id });
});

// ---------- Duplicate Spotlight ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Spotlight.findById(id).lean();
  if (!original) return notFound(res, "Spotlight not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined, // remove original ID
    title: original.title ? `${original.title} (Copy)` : "Untitled (Copy)",
    status: "draft", // duplicates default to draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await Spotlight.create(duplicatedData);

  return created(res, {
    message: "Spotlight duplicated successfully",
    duplicate,
  });
});
