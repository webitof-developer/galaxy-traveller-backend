// controllers/global.controller.js
const Global = require("../models/Global");
const { ok, notFound, fail, asyncHandler } = require("../utils/respond");

async function getOrCreateSingleton() {
  let doc = await Global.findOne();
  if (!doc) {
    // Use non-empty defaults to satisfy `required: true` and `trim: true`
    doc = await Global.create({
      name: "Global",
      description: "Site-wide defaults",
      status: "draft",
    });
  }
  return doc;
}

// Public: return the published singleton
exports.getPublished = asyncHandler(async (_req, res) => {
  const doc = await Global.findOne({ status: "published" }).lean();
  if (!doc) return notFound(res, "Global not found");
  return ok(res, doc);
});

// Moderation: read/create regardless of status
exports.getSingletonModeration = asyncHandler(async (_req, res) => {
  const doc = await getOrCreateSingleton();
  return ok(res, doc.toObject());
});

// Moderation: shallow merge update (upsert-safe)
exports.updateSingleton = asyncHandler(async (req, res) => {
  // Accept both your schema keys and legacy aliases
  const aliasMap = {
    siteName: "name",
    siteDescription: "description",
  };

  const allowed = new Set([
    "name",
    "description",
    "favicon",
    "defaultSeo",
    "status",
    "extras",
    // legacy keys allowed via aliasMap
    "siteName",
    "siteDescription",
  ]);

  // Build the $set doc, mapping aliases → real fields
  const setDoc = {};
  for (const [k, v] of Object.entries(req.body || {})) {
    if (!allowed.has(k)) continue;
    const targetKey = aliasMap[k] || k;
    setDoc[targetKey] = v;
  }

  if (Object.keys(setDoc).length === 0) {
    return fail(res, "No valid fields to update", 400);
  }

  const doc = await Global.findOneAndUpdate(
    {},
    {
      $set: setDoc,
      $setOnInsert: {
        // ensure required fields are present on first insert
        Name: "Global",
        Description: "Site-wide defaults",
      },
    },
    {
      new: true,
      upsert: true,
      runValidators: true,
      context: "query", // recommended with runValidators on FOU
    }
  ).lean();

  return ok(res, doc);
});
