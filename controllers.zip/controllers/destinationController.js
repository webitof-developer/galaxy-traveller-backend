// controllers/destination.controller.js
const Destination = require("../models/Destination");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");

// Build filters from query
const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;

  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  const experiences = csvObjectIds(req.query.experiences);
  if (experiences) f.experiences = { $in: experiences };

  const spotlights = csvObjectIds(req.query.spotlights);
  if (spotlights) f.spotlights = { $in: spotlights };

  const blogs = csvObjectIds(req.query.blogs);
  if (blogs) f.blogs = { $in: blogs };

  const tours = csvObjectIds(req.query.tours);
  if (tours) f.tours = { $in: tours };

  const tagMonths = csvObjectIds(req.query.tagMonths);
  if (tagMonths) f.tagMonths = { $in: tagMonths };

  // price range: ?minPrice=&maxPrice=
  const minP = parseFloat(req.query.minPrice);
  const maxP = parseFloat(req.query.maxPrice);

  if (!isNaN(minP) || !isNaN(maxP)) {
    f.startingPrice = {};
    if (!isNaN(minP)) f.startingPrice.$gte = minP;
    if (!isNaN(maxP)) f.startingPrice.$lte = maxP;
  }

  applyDateRange(f, req, "createdAt");
  return f;
};

function updateSubSchemaFields(updateData, subSchemaKey, schemaFields) {
  if (updateData[subSchemaKey]) {
    schemaFields.forEach((field) => {
      if (updateData[subSchemaKey][field] !== undefined) {
        updateData[`${subSchemaKey}.${field}`] =
          updateData[subSchemaKey][field];
      }
    });
    delete updateData[subSchemaKey]; // Remove the full sub-schema to avoid conflict
  }
}

// ---------- Public ----------
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { status: "published", ...buildFilters(req) };
  const search = buildSearch(req.query.q, ["title", "slug", "description"]);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Destination.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Destination.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { slug: p.toLowerCase() };
  const doc = await Destination.findOne({
    ...where,
    status: "published",
  })
    .populate("experiences")
    .populate("experiencesReverse")
    .populate("spotlights")
    .populate("spotlightsReverse")
    .populate("blogs")
    .populate("blogsReverse")
    .populate("tours")
    .populate("toursReverse")
    .populate("tagMonths")
    .populate("tagMonthsReverse")

    .lean();
  if (!doc) return notFound(res, "Destination not found");
  return ok(res, doc);
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);
  if ((req.user?.roleName || req.user?.role) == "creator") {
    where.createdBy = req.user._id;
  }
  const search = buildSearch(req.query.q, ["title", "slug", "description"]);
  if (search) Object.assign(where, search);

  // console.log(where, search, req.query.q);

  const [items, total] = await Promise.all([
    Destination.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Destination.countDocuments(where),
  ]);
  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Destination.findById(id).lean();
  if (!doc) return notFound(res, "Destination not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  const doc = await Destination.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy;

  // Update highlight sub-schema if exists
  updateSubSchemaFields(updates, "highlight", ["title", "brief", "img"]);

  const doc = await Destination.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();

  if (!doc) return notFound(res, "Destination not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await Destination.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "Destination not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Destination.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Destination not found");
  return ok(res, { id });
});

// ---------- Duplicate Destination ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Destination.findById(id).lean();
  if (!original) return notFound(res, "Destination not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined, // remove original _id
    title: original.title ? `${original.title} (Copy)` : "Untitled (Copy)",
    slug: `${original.slug || "destination"}-copy-${Date.now()}`, // unique slug
    status: "draft", // duplicate should default to draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await Destination.create(duplicatedData);

  return created(res, {
    message: "Destination duplicated successfully",
    duplicate,
  });
});
