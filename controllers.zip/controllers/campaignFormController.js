// controllers/campaignForm.controller.js
const mongoose = require("mongoose");
const CampaignForm = require("../models/CampaignForm");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");

const isObjectId = (v) => /^[0-9a-fA-F]{24}$/.test(String(v || ""));
const latestSort = (sortStr) => {
  if (!sortStr) return { createdAt: -1, _id: -1 };
  const sort = {};
  sortStr.split(",").forEach((s) => {
    s = s.trim();
    if (!s) return;
    if (s.startsWith("-")) sort[s.slice(1)] = -1;
    else sort[s] = 1;
  });
  if (!("_id" in sort)) sort._id = -1;
  return sort;
};
const parsePagination = (req) => {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
  const skip = (page - 1) * limit;
  return { page, limit, skip };
};
const buildSearch = (q) => {
  if (!q) return null;
  const rx = new RegExp(q.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
  return {
    $or: [
      { name: rx },
      { email: rx },
      { contact: rx },
      { destinations: rx },
      { needsHelp: rx },
    ],
  };
};
const coerceId = (v) => (isObjectId(v) ? new mongoose.Types.ObjectId(v) : null);
const buildCommonFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status; // moderation list allows any
  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }
  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;
  if (from || to) {
    f.createdAt = {};
    if (from && !isNaN(from)) f.createdAt.$gte = from;
    if (to && !isNaN(to)) f.createdAt.$lte = to;
    if (!Object.keys(f.createdAt).length) delete f.createdAt;
  }
  return f;
};

// -------- Public (read-only) --------
// By your pattern, public list shows only "published"
exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const search = buildSearch(req.query.q);
  const filters = buildCommonFilters(req);

  const where = { status: "published", ...(filters || {}) };
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    CampaignForm.find(where).sort(sort).skip(skip).limit(limit).lean(),
    CampaignForm.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// No slug field for CampaignForm; treat param as id only (public read single)
exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = req.params.idOrSlug;
  if (!isObjectId(p)) return notFound(res, "Invalid id");
  const doc = await CampaignForm.findOne({
    _id: p,
    status: "published",
  }).lean();
  if (!doc) return notFound(res, "CampaignForm not found");
  return ok(res, doc);
});

// -------- Moderation (protected) --------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const search = buildSearch(req.query.q);
  const filters = buildCommonFilters(req);

  const where = { ...(filters || {}) };
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    CampaignForm.find(where).sort(sort).skip(skip).limit(limit).lean(),
    CampaignForm.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await CampaignForm.findById(id).lean();
  if (!doc) return notFound(res, "CampaignForm not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const payload = {
    ...req.body,
    createdBy: req.user?._id || req.body.createdBy,
  };
  const doc = await CampaignForm.create(payload);
  return created(res, doc.toObject());
});

exports.update = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const updates = { ...req.body };
  if ("createdBy" in updates) delete updates.createdBy;
  const doc = await CampaignForm.findByIdAndUpdate(id, updates, {
    new: true,
    runValidators: true,
  }).lean();
  if (!doc) return notFound(res, "CampaignForm not found");
  return ok(res, doc);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }
  const doc = await CampaignForm.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  ).lean();
  if (!doc) return notFound(res, "CampaignForm not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await CampaignForm.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "CampaignForm not found");
  return ok(res, { id });
});

// ---------- Duplicate CampaignForm ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await CampaignForm.findById(id).lean();
  if (!original) return notFound(res, "CampaignForm not found");

  // Prepare duplicated data (remove identifiers and timestamps)
  const duplicatedData = {
    ...original,
    _id: undefined,
    name: original.name ? `${original.name} (Copy)` : "Untitled (Copy)",
    status: "draft", // new duplicate defaults to draft
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const duplicate = await CampaignForm.create(duplicatedData);

  return created(res, {
    message: "CampaignForm duplicated successfully",
    duplicate,
  });
});
