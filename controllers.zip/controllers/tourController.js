// controllers/tour.controller.js
const Tour = require("../models/Tour");
const User = require("../models/User");
const {
  ok,
  created,
  notFound,
  fail,
  asyncHandler,
} = require("../utils/respond");
const {
  isObjectId,
  coerceId,
  latestSort,
  parsePagination,
  buildSearch,
  csvObjectIds,
  applyDateRange,
} = require("../utils/query");
const { notifyUser } = require("../utils/notifyUser");
const Testimonial = require("../models/Testimonial");

// Build filters from query
const buildFilters = (req) => {
  const f = {};
  if (req.query.status) f.status = req.query.status;

  if (req.query.createdBy) {
    const id = coerceId(req.query.createdBy);
    if (id) f.createdBy = id;
  }

  // numeric ranges
  const minPrice =
    req.query.minPrice != null ? Number(req.query.minPrice) : null;
  const maxPrice =
    req.query.maxPrice != null ? Number(req.query.maxPrice) : null;
  if (!Number.isNaN(minPrice) || !Number.isNaN(maxPrice)) {
    f["priceTime.pricePerPerson"] = {};
    if (!Number.isNaN(minPrice)) f["priceTime.pricePerPerson"].$gte = minPrice;
    if (!Number.isNaN(maxPrice)) f["priceTime.pricePerPerson"].$lte = maxPrice;
    if (!Object.keys(f["priceTime.pricePerPerson"]).length)
      delete f["priceTime.pricePerPerson"];
  }

  // relations (CSV of ObjectIds)
  const blogs = csvObjectIds(req.query.blogs);
  if (blogs) f.blogs = { $in: blogs };

  const experiences = csvObjectIds(req.query.experiences);
  if (experiences) f.experiences = { $in: experiences };

  const spotlights = csvObjectIds(req.query.spotlights);
  if (spotlights) f.spotlights = { $in: spotlights };

  const tours = csvObjectIds(req.query.tours);
  if (tours) f.tours = { $in: tours };

  const destinations = csvObjectIds(req.query.destinations);
  if (destinations) f.destinations = { $in: destinations };

  const tagMonths = csvObjectIds(req.query.tagMonths);
  if (tagMonths) f.tagMonths = { $in: tagMonths };

  // optional exact place filter
  if (req.query.place) f.place = String(req.query.place).trim();

  applyDateRange(f, req, "createdAt");
  return f;
};

const searchFields = [
  "title",
  "slug",
  "place",
  "brief",
  "description",
  "tourType",
  "createdByRole",
];

// Helper function to update nested fields within a sub-schema
function updateSubSchemaFields(updateData, subSchemaKey, schemaFields) {
  if (updateData[subSchemaKey]) {
    // Iterate over each field in the sub-schema and update individually
    schemaFields.forEach((field) => {
      if (updateData[subSchemaKey][field]) {
        updateData[`${subSchemaKey}.${field}`] =
          updateData[subSchemaKey][field];
      }
    });
    // After processing individual fields, remove the whole sub-schema to avoid conflicts
    delete updateData[subSchemaKey];
  }
}

// ---------- Public ----------
// controllers/tour.controller.js

exports.listPublished = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = { status: "published", ...buildFilters(req) };

  let creator = null;

  // Handle slug or ObjectId
  if (req.query.id) {
    const val = req.query.id;

    if (mongoose.Types.ObjectId.isValid(val)) {
      // It's an ObjectId
      creator = await User.findById(val).select("_id");
    } else {
      // It's a slug
      creator = await User.findOne({ slug: val }).select("_id");
    }

    if (creator) {
      where.createdBy = creator._id;
    } else {
      // No user found = force empty result
      where.createdBy = "__NOT_FOUND__";
    }
  }

  // Optional role filter
  if (req.query.createdByRole) {
    where.createdByRole = req.query.createdByRole;
  }

  // Optional tour type filter
  if (req.query.tourType) {
    where.tourType = req.query.tourType;
  }

  // Optional search
  const search = buildSearch(req.query.q, searchFields);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Tour.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Tour.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getBySlugOrId = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { slug: p.toLowerCase() };

  const testimonialSelect =
    "name heading review stars img profileImg date travelType createdAt";

  const doc = await Tour.findOne({ ...where, status: "published" })
    .populate("tours")
    .populate("toursReverse")
    .populate("blogs")
    .populate("blogsReverse")
    .populate("tagMonths")
    .populate("tagMonthsReverse")
    .populate("destinationsReverse")
    .populate("experiencesReverse")
    .populate("spotlightsReverse")
    .populate({
      path: "createdBy",
      select: "name email profileImg bio slug",
    })
    .populate({
      path: "testimonials",
      match: { status: "published" },
      select: testimonialSelect,
      options: { sort: { createdAt: -1 } },
    })

    .lean();

  if (!doc) return notFound(res, "Tour not found");
  return ok(res, doc);
});

exports.addTestimonialPublic = asyncHandler(async (req, res) => {
  const p = String(req.params.idOrSlug || "");
  const where = isObjectId(p) ? { _id: p } : { slug: p.toLowerCase() };

  // only allow adding reviews to published tours
  const tour = await Tour.findOne({ ...where, status: "published" })
    .select("_id title createdBy")
    .lean();

  if (!tour) return notFound(res, "Tour not found");

  const user = req.user || {};
  const {
    heading,
    review,
    stars,
    travelType,
    date, // YYYY-MM-DD
    img, // array
    place,
    profileImg,
    description, // optional alias if client sends this
  } = req.body || {};

  // Basic validations mirroring Testimonial model
  if (!heading || !(review || description) || !stars) {
    return fail(res, "heading, review and stars are required", 400);
  }

  const text = String(review || description).trim();

  const starsNum = Math.max(1, Math.min(5, Number(stars)));
  const images = Array.isArray(img) ? img.filter(Boolean).slice(0, 3) : [];

  // Create Testimonial as DRAFT by default (moderation flow)
  const t = await Testimonial.create({
    tour: tour._id,
    name: String(user.name || "Guest").trim(),
    place: place ? String(place).trim() : undefined,
    travelType: travelType || undefined,
    stars: starsNum,
    date: date || new Date().toISOString().slice(0, 10),
    review: text,
    img: images,
    profileImg: profileImg || user.profileImg || undefined,
    heading: String(heading).trim(),
    status: "draft",
    createdBy: user._id || undefined,
    tourCreatedBy: tour.createdBy || undefined,
  });

  // Link onto the Tour
  await Tour.findByIdAndUpdate(
    tour._id,
    { $addToSet: { testimonials: t._id } },
    { new: false }
  );

  return created(res, {
    testimonial: t.toObject(),
    message: "Review submitted for moderation.",
  });
});

// ---------- Moderation ----------
exports.listAll = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);
  const where = buildFilters(req);
  if ((req.user?.roleName || req.user?.role) == "creator") {
    where.createdBy = req.user._id;
  }
  const search = buildSearch(req.query.q, searchFields);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Tour.find(where).sort(sort).skip(skip).limit(limit).lean(),
    Tour.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

exports.getOneModeration = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Tour.findById(id).lean();
  if (!doc) return notFound(res, "Tour not found");
  return ok(res, doc);
});

exports.create = asyncHandler(async (req, res) => {
  const createdBy = req.body.createdBy || req.user._id;
  const payload = {
    ...req.body,
    createdBy: createdBy,
  };
  const doc = await Tour.create(payload);
  return created(res, doc.toObject());
});

// controllers/tour.controller.js (replace your exports.update with this)
exports.update = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  let updates = { ...req.body };

  // --- Normalize dateRange ---
  if (updates.dateRange?.startDate && updates.dateRange?.endDate) {
    updates.dateRange = {
      startDate: new Date(updates.dateRange.startDate),
      endDate: new Date(updates.dateRange.endDate),
    };
  }
  delete updates["dateRange.startDate"];
  delete updates["dateRange.endDate"];

  // --- Load the existing document first ---
  const existing = await Tour.findById(id);
  if (!existing) return notFound(res, "Tour not found");

  // --- Handle top-level arrays properly ---
  const arrayFields = [
    "days",
    "itinerary",
    "faqs",
    "highlights",
    "moments",
    "stays",
    "galleryImgs",
    "featuredPlaces",
    "blogs",
    "experiences",
    "spotlights",
    "tours",
    "destinations",
    "tagMonths",
    "testimonials",
    "video",
  ];

  for (const f of arrayFields) {
    if (Array.isArray(updates[f])) {
      // replace full array
      existing[f] = updates[f];
      delete updates[f];
    }
  }

  // --- Update nested objects (details, inclusions) ---
  if (updates.details && typeof updates.details === "object") {
    Object.assign(existing.details, updates.details);
    delete updates.details;
  }

  if (updates.inclusions && typeof updates.inclusions === "object") {
    Object.assign(existing.inclusions, updates.inclusions);
    delete updates.inclusions;
  }

  // --- Clean up unwanted keys that can break Mongoose paths ---
  [
    "blocks.activity",
    "blocks.image",
    "blocks.notes",
    "blocks.time",
    "blocks.title",
  ].forEach((k) => {
    if (k in updates) delete updates[k];
  });

  // --- Normalize & replace `video` regardless of how the client sends it ---
  if (updates.video != null || updates.videos != null) {
    const raw = updates.video ?? updates.videos;

    let arr = [];

    if (Array.isArray(raw)) {
      arr = raw
        .map(String)
        .map((s) => s.trim())
        .filter(Boolean);
    } else if (typeof raw === "string") {
      arr = raw
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }

    // Sanitize valid URLs only
    const urlRe = /^https?:\/\/\S+$/i;
    existing.video = arr.filter((s) => urlRe.test(s));

    existing.markModified("video"); // still safe
    delete updates.video;
    delete updates.videos;
  }

  // --- Merge remaining simple fields into document ---
  Object.assign(existing, updates);

  // --- Save and validate ---
  const previousStatus = existing.status;
  const updatedTour = await existing.save();

  // --- Notify if status changed ---
  if (updatedTour.status !== previousStatus) {
    const user = await User.findById(existing.createdBy).select("email");
    if (user?.email) {
      await notifyUser({
        type: "content",
        content: {
          title: updatedTour.title,
          status: updatedTour.status,
          rejectionReason: updatedTour.rejectionReason,
          ownerEmail: user.email,
        },
      });
    }
  }

  return ok(res, updatedTour);
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const { status, rejectionReason } = req.body || {};
  if (!["draft", "published", "rejected"].includes(status)) {
    return fail(res, "Invalid status", 400);
  }

  const patch = { status };
  if (status === "rejected" && typeof rejectionReason === "string") {
    patch.rejectionReason = rejectionReason.slice(0, 500);
  }

  const doc = await Tour.findByIdAndUpdate(id, patch, {
    new: true,
    runValidators: true,
  }).lean();

  if (!doc) return notFound(res, "Tour not found");
  return ok(res, doc);
});

exports.remove = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");
  const doc = await Tour.findByIdAndDelete(id).lean();
  if (!doc) return notFound(res, "Tour not found");
  return ok(res, { id });
});

// -------- My Tours --------
exports.listMyTours = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req);
  const sort = latestSort(req.query.sort);

  const where = { createdBy: req.user._id, ...buildFilters(req) };

  const search = buildSearch(req.query.q, searchFields);
  if (search) Object.assign(where, search);

  const [items, total] = await Promise.all([
    Tour.find(where)
      .populate("destinations", "name slug") // optional populate
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .lean(),
    Tour.countDocuments(where),
  ]);

  return ok(res, {
    items,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
  });
});

// ---------- Duplicate Tour ----------
exports.duplicate = asyncHandler(async (req, res) => {
  const id = req.params.id;
  if (!isObjectId(id)) return notFound(res, "Invalid id");

  const original = await Tour.findById(id).lean();
  if (!original) return notFound(res, "Tour not found");

  // Prepare duplicated data
  const duplicatedData = {
    ...original,
    _id: undefined,
    title: original.title ? `${original.title} (Copy)` : "Untitled (Copy)",
    status: "draft",
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  // âœ… Ensure unique slug
  if (duplicatedData.slug)
    duplicatedData.slug = `${duplicatedData.slug}-copy-${Date.now()}`;

  // âœ… Handle SEO uniqueness (avoid E11000)
  if (duplicatedData.seo) {
    if (duplicatedData.seo.metaTitle)
      duplicatedData.seo.metaTitle = `${duplicatedData.seo.metaTitle} (Copy)`;

    if (duplicatedData.seo.metaDescription)
      duplicatedData.seo.metaDescription = `${duplicatedData.seo.metaDescription} (Copy)`;
  }

  // Optional: clear testimonials or related arrays if needed
  // duplicatedData.testimonials = [];

  const duplicate = await Tour.create(duplicatedData);

  return created(res, {
    message: "Tour duplicated successfully",
    duplicate,
  });
});
